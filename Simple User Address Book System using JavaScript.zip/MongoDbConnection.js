const { MongoClient, ServerApiVersion } = require('mongodb');

const connectdb = async ()=>{
  const uri = "mongodb+srv://praful:12345@cluster0.rkcg2wp.mongodb.net/?retryWrites=true&w=majority";
  const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true, serverApi: ServerApiVersion.v1 });
  let connection = await client.connect();
  let dbCon = await connection.db('details')
  let collection = await dbCon.collection('Addressbookdetails')

  return collection
}
let docObj = {name:'Dr Praful',description:'Description',img:'https://img.freepik.com/free-photo/pleased-young-female-doctor-wearing-medical-robe-stethoscope-around-neck-standing-with-closed-posture_409827-254.jpg?w=2000',ratings:'5'
}
console.log("The mongo is working")
//  class Connection{
//    constructor(obj){
//     // super()
//     this.connection = connectdb()
//     this.insertObj = obj ? obj : {};
//    }

//    async getAllDoctors(){
//       return  (await this.connection).find({}).toArray()
//    }
//    async inserDoctors(){
//     // console.log(this.insertObj)
//     if(Object.keys(this.insertObj).length>0){
//       return await (await this.connection).insertOne(this.insertObj)
//     }
//    }
// }

// let con = new Connection(docObj)
// //  console.log( con.inserDoctors().then((data)=>{
// //   console.log(data)
// //  }) )
// console.log( con.getAllDoctors().then((data)=>{
//  console.log(data)
// }) )
  